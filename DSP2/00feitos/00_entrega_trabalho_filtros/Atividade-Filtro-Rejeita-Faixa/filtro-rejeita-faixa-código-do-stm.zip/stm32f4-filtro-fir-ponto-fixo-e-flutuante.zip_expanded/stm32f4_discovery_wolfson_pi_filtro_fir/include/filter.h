#ifndef FILTER_H_
#define FILTER_H_

typedef enum FilterType {
	FIR_FLOAT32,
	FIR_Q15
} FilterTypeDef;

#endif /* UTILS_H_ */
